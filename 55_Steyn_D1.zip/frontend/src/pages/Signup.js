import React from 'react'
import Signup from '../components/splashPage/SignUp'

class SignupPage extends React.Component{
    render(){
        return(
            <div className="login_page">
                <Signup />
            </div>
        );
    }
}

export default SignupPage
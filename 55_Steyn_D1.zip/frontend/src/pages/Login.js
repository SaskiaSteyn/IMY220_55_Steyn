import React from 'react'
import Login from '../components/splashPage/Login'

class LoginPage extends React.Component{
    render(){
        return(
            <div className="login_page">
                <Login />
            </div>
        );
    }
}

export default LoginPage